import os
from flask import Flask, render_template, request, jsonify, session
from chatbot_backend import chatbot
from dotenv import load_dotenv
import pandas as pd
import numpy as np
load_dotenv()

app = Flask(__name__)
app.secret_key = "dlkfj&*((&))*^&"
data = {
    'query': ['query 1', 'query 2', 'query 3'],
    'result': [2, 5, 7]
}
df = pd.DataFrame(data)

def random_backed(query):
    if(query == 'query 1'):
        print("hi")
        df = pd.DataFrame(np.random.randint(0,100,size=(2, 4)), columns=list('ABCD'))
        
        
    else:
        df = None
    return df
@app.route('/')
def index():
    session.clear()  # Clear session on new conversation
    return render_template('index.html')

@app.route('/get_options', methods=['POST'])
def get_options():
    project = request.json.get('project')
    discipline = request.json.get('discipline')

    if project and discipline:
        dashboards = ['total manhour dashboard', 'validation tag dashboard']
        return jsonify(dashboards=dashboards)
    return jsonify(error="Missing project or discipline"), 400

@app.route('/get_queries', methods=['POST'])
def get_queries():
    dashboard = request.json.get('dashboard')

    if dashboard:
        queries = df['query'].tolist()
        return jsonify(queries=queries)
    return jsonify(error="Missing dashboard"), 400

@app.route('/get_result', methods=['POST'])
def get_result():
    # breakpoint()
    query = request.json.get('query')
    
    result = random_backed(query)
    
    # return jsonify({'result': result})
    #result = result.to_json()
    cols = result.values.tolist()
    vals = list(result.columns.values)
    return jsonify(result_header=vals, result_val =cols)

@app.route('/send_to_chatbot', methods=['POST'])
def send_to_chatbot():
    data = request.json
    selected_query = data.get('query')
    # Send the query to the chatbot and get a response
    chatbot_response = chatbot.get_response(selected_query)
    return jsonify({'chatbot_response': chatbot_response})

if __name__ == '__main__':
    app.secret_key = 'super secret key'
    app.config['SESSION_TYPE'] = 'filesystem'
    app.run(debug=True)
