from flask import Flask, render_template, request, jsonify
from chatbot_backend import dashboard_dax_fetch as dax
from chatbot_backend import power_bi_api as pbi

app = Flask(__name__)

conversation_state = {}

# def queries_list():
#     return [
#         "total manhours by registers",
#         "total manhours for Aug 2024",
#         "project progress by week",
#     ]

# def projects():
#     return ["TAMIL", "HINDI", "ENGLISH"]

# def discipline():
#     return ["Fiction", "Non-Fiction", "Sci-fi"]

# def chatbot_response(query, conversation_state):
#     # Default responses for a new conversation
#     if 'greeted' not in conversation_state:
#         conversation_state['greeted'] = True
#         return "Hi there! What project and discipline are you asking about?", conversation_state
    
#     # Set the project in the conversation state
#     if 'project' not in conversation_state:
#         conversation_state['project'] = query
#         return "Thanks! And what discipline?", conversation_state
    
#     # Set the discipline in the conversation state
#     if 'discipline' not in conversation_state:
#         conversation_state['discipline'] = query
#         recommended_queries = queries_list()
#         return f"What would you like to know? Here are some suggestions: {', '.join(recommended_queries)}", conversation_state
    
#     # Handle selected queries
#     if 'selected_query' not in conversation_state:
#         conversation_state['selected_query'] = query.lower()
#         if conversation_state['selected_query'] == "total manhours by registers":
#             return "Please specify the register.", conversation_state
#         if conversation_state['selected_query'] == "total manhours for aug 2024":
#             return "Please specify the date range.", conversation_state
#         return f"Fetching information on {conversation_state['selected_query']}.", conversation_state
    
#     # Provide results based on the specified query
#     if 'selected_query' in conversation_state:
#         if conversation_state['selected_query'] == "total manhours by registers":
#             return f"Fetching total manhours for register {query}.", conversation_state
#         if conversation_state['selected_query'] == "total manhours for aug 2024":
#             return f"Fetching total manhours for the date range {query}.", conversation_state

#     return "I'm sorry, I didn't understand that.", conversation_state

# @app.route('/')
# def index():
#     return render_template('index.html')

# @app.route('/chat', methods=['POST'])
# def chat():
#     user_input = request.json.get('query')
#     response, updated_state = chatbot_response(user_input, conversation_state)
#     conversation_state.update(updated_state)
#     return jsonify({'response': response})
def powerbi_query(query, conversation_state):
    pass

def chatbot_main(query):
    name, dax_result = dax.main(query)
    workspace_id = pbi.WORKSPACE_ID
    dataset_id = pbi.DATASET_ID
    print('Name', 'Dax Result', name, dax_result)
    response = pbi.execute_dax_query(workspace_id, dataset_id, dax_result)
    
    # Return the response
    return response
    

if __name__ == '__main__':
    app.run(debug=True)
