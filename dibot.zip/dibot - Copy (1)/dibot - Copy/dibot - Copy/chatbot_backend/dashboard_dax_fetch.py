import os
import pandas as pd
import Levenshtein as lev
import nltk


from nltk.tokenize import word_tokenize
import time

def load_dax_links():
    df = pd.read_excel("C:\intern\dibot - Copy (1)\dibot - Copy\dibot - Copy\chatbot_backend\static\manhours_dax_repo.xlsx"
                  , sheet_name='Sheet1', engine='openpyxl')
    return df

def load_data_csv(file_path):
    return pd.read_csv(file_path)
def lowercase_all(df):
    df = df.apply(lambda x: x.lower() if isinstance(x, str) else x)
    return df
def tokenize_text(text):
    return word_tokenize(text) if isinstance(text, str) else []
def compute_levenshtein_distance(query_tokens, entry_tokens):
    distances = []
    for query_token in query_tokens:
        for entry_token in entry_tokens:
            distance = lev.distance(query_token, entry_token)
            distances.append(distance)
    return min(distances) if distances else float('inf')
def calculate_distances(df, query):
    query_tokens = tokenize_text(query)
    results = []
    for index, row in df.iterrows():
        row_distances = []
        for column in df.columns:
            entry = row[column]
            entry_tokens = tokenize_text(entry)
            distance = compute_levenshtein_distance(query_tokens, entry_tokens)
            row_distances.append((column, distance))
        min_distance = min(row_distances, key=lambda x: x[1])[1]
        results.append((index, min_distance))
    return results
def find_best_match(distances):
    best_match = min(distances, key=lambda x: x[1], default=None)
    return best_match
def process_data(query):
    df = load_dax_links()
    # print(df)
    df = lowercase_all(df)
    query = query.lower()
    distances = calculate_distances(df, query)
    best_match = find_best_match(distances)
    return best_match, df
def main(user_query):
    user_query = user_query
    best_match, df = process_data(user_query)
    if best_match is not None:
        index, distance = best_match
        print("Query given:", user_query)
        # print("Best Match Found at index:", index)
        print("Distance:", distance)
        row_selection = df.iloc[index]
        # print(row_selection)
        #  df.iloc[2, df.columns.get_loc('age')]
    else:
        print("No match found")
    return row_selection['DASHBOARD_NAME'], row_selection['DAX']


if __name__ == "__main__":
    user_query = input("Enter the query to match: ")
    start_time = time.time()
    name,dax = main(user_query)
    print("Dashboard Name:", name)
    print("DAX:", dax)
    end_time = time.time()
    runtime = end_time - start_time
    print(f"Runtime: {runtime} seconds")